
public class Mesa {

	private boolean[] tenedores;

	public Mesa(int numeroTenedores) {
		this.tenedores = new boolean[numeroTenedores];
	}

	public int tenedorIzquierda(int i) {
		return i;

	}

	public int tenedorDerecha(int i) {
		if (i == 0) {
			return this.tenedores.length - 1;
		}else {
			return i - 1;
		}
		
	}

	public synchronized void cogerTenedores(int comensal) {
		while (tenedores[tenedorIzquierda(comensal)] || tenedores[tenedorDerecha(comensal)]) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		tenedores[tenedorIzquierda(comensal)]=true;
		tenedores[tenedorDerecha(comensal)]=true;
	}
	
	public synchronized void DejarTenedores(int comensal) {
		tenedores[tenedorIzquierda(comensal)]=false;
		tenedores[tenedorDerecha(comensal)]=false;
		notifyAll();
		
	}
	
	

}
