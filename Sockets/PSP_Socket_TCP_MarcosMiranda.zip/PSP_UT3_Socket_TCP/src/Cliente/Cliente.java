package Cliente;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;


public class Cliente {

    public static void main(String[] args) {

        try {
            Socket socketCliente = new Socket("localhost", 2000); // le decimos que se conecte a la ip local, y al puerto 2000 del servidor que hemos creado

            try {
                // flujo de comunicación
                InputStream ficheroEntrada = socketCliente.getInputStream();
                DataInputStream flujoEntrada = new DataInputStream(ficheroEntrada);
                String datosRecibidos = flujoEntrada.readUTF();
                System.out.println(datosRecibidos);

                OutputStream ficheroSalida = socketCliente.getOutputStream();
                DataOutputStream flujoSalida = new DataOutputStream(ficheroSalida);
                flujoSalida.writeUTF("Hola servidor");
            } finally {
                // Cierre de flujos
                socketCliente.close();
            }

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
