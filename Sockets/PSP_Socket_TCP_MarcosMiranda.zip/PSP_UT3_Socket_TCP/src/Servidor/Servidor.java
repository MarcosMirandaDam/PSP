package Servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

    public static void main(String[] args) {

        final int puerto = 2000; // damos valor 2000 al puerto

        ServerSocket socketServidor = null;

        try {
            socketServidor = new ServerSocket(puerto); // creamos el serverSocket en el puerto deseado

            System.out.println("Escuchando peticiones en el puerto-->" + puerto);

            // Intercambio de datos con el cliente
            for (int i = 0; i < 3; i++) {
                Socket socketCliente = socketServidor.accept(); // inicializamos , lo ponemos en espera... a que un cliente se conecte
                System.out.println("Servidor atendiendo al cliente " + i);
                
                OutputStream ficheroSalida = socketCliente.getOutputStream();
                DataOutputStream flujoSalida = new DataOutputStream(ficheroSalida);
                flujoSalida.writeUTF("Cliente " + i + " ha sido atendido por el servidor");
                
                try {
                    InputStream ficheroEntrada = socketCliente.getInputStream();
                    DataInputStream flujoEntrada = new DataInputStream(ficheroEntrada);
                    String datosRecibidos = flujoEntrada.readUTF();
                    System.out.println(datosRecibidos);
                } finally {
                    // Cerramos los flujos en el bloque finally para asegurarnos de que se cierren incluso si ocurre una excepción
                    socketCliente.close();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (socketServidor != null)
                    socketServidor.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
