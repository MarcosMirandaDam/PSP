package conSemaforo;

/**
 * @author Marcos Miranda Clase Productor, que creará un dato, para que un
 *         consumidor lo consuma. Hilo Productor
 */
public class Productor extends Thread {

	private Dato dato; 						// recurso compartido por productor y consumidor
	private String nombre;					//nombre del productor

	/**
	 * Constructor
	 * 
	 * @param dato
	 * @param nombre
	 */
	public Productor(Dato dato, String nombre) {
		super();
		this.dato = dato;
		this.nombre = nombre;
	}

	/**
	 * Método que produce un dato.
	 */
	public void run() {

		for(int i=0;i<5;i++) {
			dato.producirDato( " "+i+ " creado por el productor "+nombre);
		}
	}

}
