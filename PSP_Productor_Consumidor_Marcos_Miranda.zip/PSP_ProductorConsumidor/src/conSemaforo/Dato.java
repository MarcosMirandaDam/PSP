package conSemaforo;

/**
 * @author Marcos Miranda
 * 
 */
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Dato {

	private String dato;

	private volatile boolean hayDato = false;

	private Semaphore semaforo = new Semaphore(1); // decidir numero de hilos a region critica

	/**
	 * consumidor
	 * 
	 * @return
	 */
	public void producirDato(String n) {

		while (hayDato) {
				//esperamos mientras el consumidor tira del dato producido
		}
		
		try {

			semaforo.acquire();
			dato=n;
			hayDato=true;
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			semaforo.release();

		}
		
	}

	/**
	 * productor..
	 * 
	 * @param d
	 */
	public String consumirDato() {
		
		String resultado="";
		
		while (!hayDato) {
			//esperamos mientras el productor fabrique un dato
		}
		
		try {
			semaforo.acquire();
			resultado=dato;
			hayDato=false;

			

		} catch (InterruptedException ex) {
			Logger.getLogger(Dato.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			semaforo.release();

		}
		return resultado;

	}

}
