package conSemaforo;

/**
 * @author Marcos Miranda
 */
public class Consumidor extends Thread {

	private Dato dato;							//objeto Dato a consumir
	private String nombre;						//nombre del consumidor
	
	/**
	 * constructor clase Consumidor
	 * @param dato
	 * @param nombre
	 */
	public Consumidor(Dato dato, String nombre) {
		super();
		this.dato = dato;
		this.nombre = nombre;
	}


	/**
	 * metodo que consume un dato
	 */
	public void run() {

		for(int i=0;i<5;i++) {
			System.out.println(nombre + " Consumiendo el dato---->" +dato.consumirDato());
		}
	}

}
