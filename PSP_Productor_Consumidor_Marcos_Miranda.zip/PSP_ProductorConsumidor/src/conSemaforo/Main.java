package conSemaforo;

public class Main {

	public static void main(String[] args) {

		final int PRODUCTOR=3;		//constante numero de productores
		final int CONSUMIDOR=1;		//constante numero de consumidores
		
		Dato miDato=new Dato();
		
		Productor p1=new Productor(miDato,"Productor 1");
		
		Consumidor c1=new Consumidor(miDato, "Consumidor 1");
		Consumidor c2=new Consumidor(miDato, "Consumidor 2");
		Consumidor c3=new Consumidor(miDato, "Consumidor 3");
		Consumidor c4=new Consumidor(miDato, "Consumidor 4");
		
		p1.start();
		c1.start();
		c2.start();
		c3.start();
		c4.start();
		

	}

}
