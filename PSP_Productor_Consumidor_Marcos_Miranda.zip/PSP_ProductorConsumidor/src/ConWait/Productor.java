package ConWait;

/**
 * @author Marcos Miranda
 */
public class Productor extends Thread {

	private Dato dato;							// recurso compartido por productor y consumidor

	private String nombre;						//nombre del productor

	/**
	 * constructor
	 * @param d
	 * @param n
	 */
	public Productor(Dato d, String n) {
		dato = d;
		nombre = n;
	}

	/**
	 * metodo que produce datos
	 */
	public void run() {

		for (int i = 0; i < 5; i++) {

			dato.meterNuevoDato(nombre + " " + i);
		}
	}

}
