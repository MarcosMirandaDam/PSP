package ConWait;

/**
 * @author Marcos Miranda
 */
public class Consumidor extends Thread {

	private Dato dato;						// recurso compartido por productor y consumidor
	private String nombre;					//nombre del consumidor

	/**
	 * constructor
	 * @param d
	 * @param n
	 */
	public Consumidor(Dato d, String n) {

		dato = d;
		nombre = n;

	}

	/**
	 * metodo que produce consumidores
	 */
	public void run() {

		for (int i = 0; i < 5; i++) {

			System.out.println(nombre + "consumiendo el dato:" + dato.getDato());
		}
	}

}
