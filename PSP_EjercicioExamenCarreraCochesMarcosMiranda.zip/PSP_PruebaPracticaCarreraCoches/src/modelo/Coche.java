package modelo;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;

/**
 * @author Marcos Miranda. DAM Distancia 2024
 */
public class Coche extends Thread{

	CyclicBarrier barrera;
	CountDownLatch cuentaAtras;
	
	public Coche(CyclicBarrier ba,CountDownLatch ca,int i) {
		barrera=ba;
		cuentaAtras=ca;
		this.setName("Coche "+i);
	}
	
	public void run() {
		
		System.out.println(" Arrancando "+this.getName());
		
		
			try {
				barrera.await();
				cuentaAtras.await();
				System.out.println("Acelera el coche "+this.getName());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (BrokenBarrierException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
	}
}
