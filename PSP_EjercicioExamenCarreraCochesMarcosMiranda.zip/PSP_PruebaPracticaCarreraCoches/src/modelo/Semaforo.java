package modelo;

import java.util.concurrent.CountDownLatch;

/**
 * @author Marcos Miranda. DAM Distancia 2024
 */
public class Semaforo extends Thread{

	CountDownLatch cuentaAtras;
	
	public Semaforo(CountDownLatch ca) {
		cuentaAtras=ca;
				
	}

	@Override
	public void run() {
		System.out.println("Semaforo en rojo.... 3 segundos....");
		try {
			Thread.sleep(3000);
			System.out.println("Semaforo en verde!!..Comienza la carrera....");
			cuentaAtras.countDown();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
