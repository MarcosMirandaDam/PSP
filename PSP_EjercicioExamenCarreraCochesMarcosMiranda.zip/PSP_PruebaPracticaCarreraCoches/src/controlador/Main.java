package controlador;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;

import modelo.Coche;
import modelo.Semaforo;

/**
 * @author Marcos Miranda. DAM Distancia 2024
 */
public class Main {

	public static void main(String[] args) {
		
		int numeroCoches=10;
		CyclicBarrier barrera=new CyclicBarrier(numeroCoches+1);    //sumamos el hilo main
		CountDownLatch cuentaAtras=new CountDownLatch(1);
		Semaforo semaforo=new Semaforo(cuentaAtras);
		
		for(int i=0;i<10;i++) {
			Coche c=new Coche(barrera,cuentaAtras,i);
			c.start();
		}
		
		//empezamos carrera
		try {
			barrera.await();
			semaforo.start();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BrokenBarrierException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
