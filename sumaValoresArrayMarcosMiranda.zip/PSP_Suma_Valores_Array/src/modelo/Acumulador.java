package modelo;

/**
 * Calcular la suma de los valores de un array de enteros de tamaño 1.000.000,
 * de manera paralela por 10 hilos.
 * 
 * @author Marcos Miranda
 */
public class Acumulador extends Thread {

	private int[] arrayEnteros;
	private int inicioValor;
	private int finValor;
	private long sumaParcial;

	/**
	 * constructor de la clase Acumulador
	 * 
	 * @param arrayEnteros
	 * @param inicioValor
	 * @param finValor
	 */
	public Acumulador(int[] arrayEnteros, int inicioValor, int finValor) {

		this.arrayEnteros = arrayEnteros;
		this.inicioValor = inicioValor;
		this.finValor = finValor;

	}

	/**
	 * metodo para acceder al dato acumulado en el momento deseado
	 * 
	 * @return
	 */
	public long getSumaParcial() {
		return sumaParcial;
	}

	/**
	 * metodo que ejecutará el hilo
	 */
	@Override
	public void run() {

		sumaParcial = 0;
		for (int i = inicioValor; i < finValor; i++) {
			sumaParcial += arrayEnteros[i];

		}
		System.out.println("Acumulador " + this.getName() + " acumulando resultado" + sumaParcial);

	}

}