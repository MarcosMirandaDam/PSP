package controlador;

import modelo.Acumulador;

/**
 * //Calcular la suma de los valores de un array de enteros de tamaño 1.000.000,
 * de manera paralela por 10 hilos.
 * 
 * @author Marcos Miranda
 */
public class MainSumaArray {

	public static void main(String[] args) {

		final int NUMERO_HILOS = 10; // numero final de hilos a trabajar
		final int TAMANIO_ARRAY = 100; // tamaño final del array de enteros para trabajar
		int inicioValor;
		int finValor;

		int[] arrayEnteros = new int[TAMANIO_ARRAY]; // inicializamos el array de enteros
		for (int i = 0; i < arrayEnteros.length; i++) {
			arrayEnteros[i] = i + 1;
		}

		int tramoArray = arrayEnteros.length / NUMERO_HILOS; // sacamos las 10 partes del array

		Acumulador[] hilosParalelos = new Acumulador[NUMERO_HILOS]; // almacenaremos los datos de cada tramo

		for (int i = 0; i < NUMERO_HILOS; i++) { // creamos y ejecutamos los hilos
			inicioValor = i * tramoArray;
			if (i == NUMERO_HILOS - 1) {
				finValor = arrayEnteros.length;
			} else {
				finValor = (i + 1) * tramoArray;
			}

			hilosParalelos[i] = new Acumulador(arrayEnteros, inicioValor, finValor);    // creamos la instancia de cada
																						// hilo acumulador
			hilosParalelos[i].start();

		}

		try {

			for (int i = 0; i < NUMERO_HILOS; i++) { // esperamos finalizacion de los hilos
				hilosParalelos[i].join();
			}

			long sumaTotal = 0; // suma de los resultados paralelos
			for (int i = 0; i < NUMERO_HILOS; i++) {
				sumaTotal += hilosParalelos[i].getSumaParcial();
			}

			System.out.println("La suma total es -->" + sumaTotal); // mostramos resultado final

		} catch (InterruptedException ex) {
			ex.printStackTrace();

		}

	}

}
